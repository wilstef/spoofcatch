
function showFunction(img) {
    var x = document.getElementById("img").img;
    document.getElementById("demo").innerHTML = x;
}

var BASE64_MARKER = ';base64,';

function convertDataURIToBinary(dataURI) {
  var BASE64_MARKER = ';base64,';
  var base64Index = dataURI.indexOf(BASE64_MARKER) + BASE64_MARKER.length;
  var base64 = dataURI.substring(base64Index);
  var raw = window.atob(base64);
  var rawLength = raw.length;
  var array = new Uint8Array(new ArrayBuffer(rawLength));

  for(i = 0; i < rawLength; i++) {
    array[i] = raw.charCodeAt(i);
  }
  return array;
}

function saveBase64AsFile(base64, fileName) {
	var link = document.createElement("a");
	link.setAttribute("href", base64);
	link.setAttribute("download", fileName);
	link.click();
}

//get a base64 encoded image from an in local directory. 
function getBase64FromImageUrl(url) {
    var img = new Image();
    var image;
    img.setAttribute('crossOrigin', 'anonymous');

    img.onload = function () {
        var canvas = document.createElement("canvas");
        canvas.width =this.width;
        canvas.height =this.height;

        var ctx = canvas.getContext("2d");
        ctx.drawImage(this, 0, 0);

        var dataURL = canvas.toDataURL("image/jpeg");
		console.log('Flower b64 data 1: ', dataURL);
		console.log('Flower unit8 data 1: ', convertDataURIToBinary (dataURL));
		image = dataURL;
        //alert(dataURL.replace(/^data:image\/(png|jpg);base64,/, ""));
    };

    img.src = url;
}















    /*********Read image file names**********/	
	//var pagehost;
	var imgpath;
	var hnames = gethnames(); 		 //read images data from 'hostnames.js' file
	var tuples = hnames.split(",");  //A 'tuples' is a list of tuples 
	var i;
	
	
	//get image from folder and store in the database 
	for (i=0; i < tuples.length; i++)  {
		
		var tuple = tuples[i].split("::"); //a tuple is a data structure including optional message 'MANUALLY-DETECTED', host-name and URL of the iamge).
		if (tuple[0] != 'MANUALLY-DETECTED')
			pagehost = tuple[0];
		else 
			pagehost = tuple[1];
		//setTimeout(() => {	
			//add existing loginpage screenshots to database
			extension.addImgsToDatabase(pagehost, loginpagesDba);	
		//}, 100);
	}
	
	/******************************************/
	
	//manual login page capture-click icon if login page is not automatically identified.
	chrome.browserAction.onClicked.addListener( function(tab) { 
		if (true) { //validUrl(tab.url)) {
			extension.caputreLoginPage(tab,loginpagesDba, false);  			
		}
		else 
			alert("\nInvalid web page! \nPlease try on a different web page.");
	});
	
	//automatic login page capture
	chrome.runtime.onMessage.addListener(	
	
		//listen to receive msg from content script-when a login page is detected.
		function (message, sender, sendResponse) {	
			//If login page detected with valid URL, capture and add it to disc
			if (message.type === 'LOGIN-PAGE' & validUrl(sender.tab.url))  {
				//console.log("\nLogin page identified!");
				extension.caputreLoginPage(sender.tab,loginpagesDba, true);  	
			}
	    }
	);
  