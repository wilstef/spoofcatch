phash.js
========

perceptual hashing in javascript
