/* Get all login forms in the page. */
function getLoginForms() {
	return $("form").filter(function () {
		return $("input[type='password']", this).length >= 1;
	}).clone().map(function () {
		var fields = $(this).find("input, select, textarea").clone().map(function () {
			if ($(this).attr("type") === "hidden")
				return $(this);
			if ($(this).attr("type") === "submit")
				return $("<tr>").append([$("<td>"), $("<td>").append($(this).removeAttr("disabled"))]);
			if ($(this).attr("id") === undefined)
				$(this).attr("id", $(this).attr("name"));
			var label = $("label[for='{0}']".format($(this).attr("id")));
			return $("<tr>").append(
				[$("<td>").append($("<label>").attr("id", $(this).attr("id")).html(label.length === 0 ? $(this).attr("id") : label.text())), $("<td>").append($(this))]
			);
		}).get();
		$(this).empty().append($("<table>").append(fields));
		if ($("input[type='submit']", this).length === 0)
			return $(this).append($("<input>").attr("type", "submit")).prop("outerHTML");
		return $(this).append($("input[type='submit']", $(this))).prop("outerHTML");
	}).get();
}

/* If login forms are found in the page, clone them in order to be used in a popup action page. */
var loginForms = getLoginForms();
if (loginForms.length > 0)
  chrome.runtime.sendMessage({type: 'LOGIN-PAGE'});
