

var onsuccessput = function(id){
  //console.log('Yeah, dude inserted! insertId is: ' + id);
}

var dbclearsuccess = function( ){
  console.log('The login pages database is CLEARED!');  
  //console.log("\nLogin pages HOST-NAME and URL:\n\n");   
}

var onerrror = function(error){
  console.log('Oh noes, sth went wrong!', error);
}
  
 //Creates a new store 'loginpagesDba' insdie the same IndexedDB, for storing first 250 pages
 var loginpagesDba = new IDBStore({ 
		dbVersion: 1,
		storeName: "loginpagestorea",
		keyPath: 'host',
		onStoreReady: onLoginPageStoreReadya,
		onError: function (error) {
			debug("Failure on loading redirects DB: {0}".format(error), DEBUG_ERROR);
		}
	});
	
function onLoginPageStoreReadya() {	
    //NOTE: preceding 'var' before database object inside function gives error. 
	loginpagesDbb = new IDBStore({   
		dbVersion: 1,
		storeName: "loginpagestoreb",
		keyPath: 'host',
		onStoreReady: onLoginPageStoreReadyb,
		onError: function (error) {
			debug("Failure on loading redirects DB: {0}".format(error), DEBUG_ERROR);
		}
	});		
}
	
function onLoginPageStoreReadyb() {
	loginpagesDbc = new IDBStore({ 
		dbVersion: 1,
		storeName: "loginpagestoreac",
		keyPath: 'host',
		onStoreReady: onLoginPageStoreReadyc,
		onError: function (error) {
			debug("Failure on loading redirects DB: {0}".format(error), DEBUG_ERROR);
		}
	});	
}

function onLoginPageStoreReadyc() {
	
	extension = new Extension(loginpagesDba);		
	loginpagesDba.clear(dbclearsuccess, onerror);
	loginpagesDbb.clear(dbclearsuccess, onerror);
	loginpagesDbc.clear(dbclearsuccess, onerror);
	
    /*********Read image file names**********/	
	//var pagehost;
	var imgpath;
	var hnames = gethnames(); 		 //read images data from 'hostnames.js' file
	var tuples = hnames.split(",");  //A 'tuples' is a list of tuples 
	var i;
	
/*
	var hostnames = " ";
	var testtuples = [];
	var j = 0;
	for (i=0; i < tuples.length; i++)  { 		
		if (testtuples.indexOf(tuples[i]) < 0) {
			testtuples[j++]=tuples[i];	
			hostnames = hostnames + ",\"+\n"+ "\""+tuples[i];
		}
	}
	console.log('Testtuples: '+ hostnames);
*/

	//get image from folder and store in the database 
	for (i=0; i < tuples.length; i++)  {  //tuples.length;
			
		var tuple = tuples[i].split("::"); //a tuple is a data structure including optional message 'MANUALLY-DETECTED', host-name and URL of the iamge).
		if (tuple[0] != 'MANUALLY-DETECTED')
			pagehost = tuple[0];
		else 
			pagehost = tuple[1];
				
		//add first 250 pages from stored images to databaseA and add the rest to databaseB.
		if (i < 250)
			extension.addImgsToDatabase(pagehost, loginpagesDba);
		else
			extension.addImgsToDatabase(pagehost, loginpagesDbb);
	}
	
	
	//Three databases: dba stores first 250 pages, dbb stores the rest. All the new login pages are stored in dbc. 
	var databases = {
		dba: loginpagesDba,
		dbb: loginpagesDbb,
		dbc: loginpagesDbc		
	}
	/******************************************/
	
	//manual login page capture-click icon if login page is not automatically identified.
	chrome.browserAction.onClicked.addListener( function(tab) { 
		if (true) { //validUrl(tab.url)) {
			extension.caputreLoginPage(tab, databases, false);  			
		}
		else 
			alert("\nInvalid web page! \nPlease try on a different web page.");
	});
	
	//automatic login page capture
	chrome.runtime.onMessage.addListener(		
		//listen to receive msg from content script-when a login page is detected.
		function (message, sender, sendResponse) {	
			//If login page detected with valid URL, capture and add it to disc
			if (message.type === 'LOGIN-PAGE' & validUrl(sender.tab.url))  {
				//console.log("\nLogin page identified!");
				extension.caputreLoginPage(sender.tab, databases, true);  	
			}
	    }
	);
}


	
	
	