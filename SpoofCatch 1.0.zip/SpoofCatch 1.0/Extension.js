

//pass arguments for initialization
function Extension(loginpagesDB) {
  this.database = loginpagesDB;
  this.capturedpage;
}

var onerror = function(error){
  console.log('Something went wrong in re-trieving login pages from database!', error); }

Extension.prototype.createOjbect = function (image1, image2) {
	const rembrandt = new Rembrandt({
		// `imageA` and `imageB` can be either Strings (file path on node.js,
		// public url on Browsers) or Buffers
		imageA: image1,
		imageB: image2,

		// Needs to be one of Rembrandt.THRESHOLD_PERCENT or Rembrandt.THRESHOLD_PIXELS
		thresholdType: Rembrandt.THRESHOLD_PERCENT,

		// The maximum threshold (0...1 for THRESHOLD_PERCENT, pixel count for THRESHOLD_PIXELS
		maxThreshold: 0.01,

		// Maximum color delta (0...255):
		maxDelta: 20,

		// Maximum surrounding pixel offset
		maxOffset: 0,

		renderComposition: true, // Should Rembrandt render a composition image?
		compositionMaskColor: Rembrandt.Color.RED // Color of unmatched pixels
	});

   return rembrandt;
};

Extension.prototype.ssim = function () {
    var imagePairs = [
		['testimages/flower.jpg', 'testimages/flower-blur.jpg', 8, true, 'Blur'],
		['testimages/palette-a.png', 'testimages/palette-b.png', 8, true],
		['testimages/palette-a.png', 'testimages/wheel-pixelized.png', 8, true],
		['testimages/wheel.png', 'testimages/wheel-pixelized.png', 8, true],
		['testimages/wheel.png', 'testimages/wheel-pixelized.png', 32, true]
	];
	
  return imagePairs[0];
};

//Rembrandt similrity of two images
simRembrandt = function(image1, image2) {
	var remsim = 1;
	var queue = Promise.resolve(); // start waiting	
	
	queue = queue.then(function(result) {
		const rembrandt = new Rembrandt({
			imageA: image1.datab64,
			imageB: image2.datab64,
			// Needs to be one of Rembrandt.THRESHOLD_PERCENT or Rembrandt.THRESHOLD_PIXELS
			thresholdType: Rembrandt.THRESHOLD_PERCENT,
			// The maximum threshold (0...1 for THRESHOLD_PERCENT, pixel count for THRESHOLD_PIXELS
			maxThreshold: 0.5,
			// Maximum color delta (0...255):
			maxDelta: 20,
				// Maximum surrounding pixel offset
				maxOffset: 0,
				renderComposition: true, // Should Rembrandt render a composition image?
				compositionMaskColor: Rembrandt.Color.RED // Color of unmatched pixels
		});		
		
		return rembrandt.compare(); //visitPage(url);
	});
	queue.then(function(result) {
		//console.log('Comparision of: ', image1.url);
		//console.log('With : ', image2.url);
		//console.log('Passed:', result.passed);
		//console.log('Pixel Difference:', result.differences, 'Percentage Difference', result.percentageDifference, '%');
		//console.log('Composition image buffer:', result.compositionImage); 
		remsim = 1-result.percentageDifference;
		remsim = Math.round(remsim * 1000) / 1000;
		//console.log(" Rembrandt similarity: " + remsim);
		return remsim;
	});
};

//Structural similarity of two images
function  simSSIM (image1, image2) { 
	
	//var flower = this.ssim();
	
	var res = ImageSSIM.compare(image1, image2, 8, 0.01, 0.03, true);
	var ssim = Math.round(res.ssim * 1000) / 1000;
		
	//Rembrandt image comparison (pixel by pixel comparision), not accurate
	//this.compareImages (image1, image2);
	return ssim;
 };
  
function percepSim(hash1, hash2) {
	
	var similarity = hash1.length;  
	var key;
	
	for(key=0; key<hash1.length; key++) {
		if(hash1[key] != hash2[key])
			similarity--;
	}

	var phashsim = ((similarity*100)/hash1.length).toFixed(2); 
	phashsim = phashsim / 100;  //rounded similarity
	phashsim = Math.round(phashsim * 1000) / 1000;
	
	return phashsim;
 };
	 
 Extension.prototype.addImgsToDatabase = function (pagehost, database) {
		
		var imgpath;
			
		imgpath = 'CapturedPages/'+pagehost+'.jpeg';
		
		//console.log("Image path: " + imgpath);
		
		//create image object for login page identified
		var loginpage = new Image();   				
		loginpage.onload = function () {
		    var canvas = document.createElement("canvas");
			canvas.width= 340; //this.width;
			canvas.height= 340; //this.height;						
			var ctx = canvas.getContext('2d');
			ctx.drawImage(loginpage, 0, 0, canvas.width, canvas.height);						
			var imgdata = ctx.getImageData(0, 0, canvas.width, canvas.height); //ImageData object
			var imgdatab64 = canvas.toDataURL("image/jpeg");  //base64 data
						
			//prepare image data structure. First FIVE fields are for structural similarity 
			var loginimage = {		
				data: imgdata.data, 
				channels: 4,		
				width: 340, //img.width,
				height: 340, //img.height		
				canvas: null,				
				datab64: loginpage.src, //imgsource, //imgdatab64,		//for rembrandt browser	
				url: pagehost, //May need to be replaced with a url,				//for rembrandt browser
				host: pagehost
			};						
							
			//console.log("Page host: "+loginimage.host);
			database.put(loginimage, onsuccessput, onerrror);
		}
		// img2.src = 'loginpages/facebook1.png';
		loginpage.src = imgpath;   //putting this above may create problems due to synchronous functions		
}

function phishCheck (data, loginpage, loginimage) {
	var phashsim;
	var rembrandsim;
	
	var tau1ssim = 0.85;
	var tau2ssim = 0.75;
	var tau1phash = 0.66;
	var tau2phash = 0.59;
	
	var Tau1 = tau1ssim+tau1phash/2;  //0.755 (high, corresponds to level-1 (high) security concern)
	var Tau2 = tau2ssim+tau2phash/2;  //0.67  (low, corresponds to level-2 (low) security concern)
	
	var VSI = 0; //Visual Similarity Index-default is 0
	
	var found = false;
	
	//Notification displayed to user (customized for lower and higher threat levels)
	var notifoption = {
        type: 'basic',
        iconUrl: 'icons/icon48.png',    //default icond-showed for lower phishing risk
        title: 'Phishing Warning!'  //,
       // message: 'You probably are under phishing attack!'
     };
	 
	if (data.length > 0) 		//if non-empty						
		data.forEach(function(item) {
							
		var structuralsim;	
							
		//console.log("\n Domain of the page: " + item.domain);	
		if (loginimage.host != item.host) {
			
			//create image object from the items stored in database and compare with current login page
			var imgitem = new Image();
			imgitem.onload = function () {
				var canvas = document.createElement("canvas");
				canvas.width= 340; //this.width;
				canvas.height= 340; //this.height;						
				var ctx = canvas.getContext('2d');
				ctx.drawImage(imgitem, 0, 0, canvas.width, canvas.height);						
				var imgdata = ctx.getImageData(0, 0, canvas.width, canvas.height); //ImageData object
				var imgdatab64 = canvas.toDataURL("image/jpeg");  //base64 data	
								
				//console.log("\nSimilarity of: \n " + loginimage.url + "  with\n " + item.url);
				structuralsim = simSSIM(loginimage, item);	
				//console.log(" SSIM similarity: " + structuralsim);
								
				phashsim = percepSim(pHash(loginpage), pHash(imgitem));
				//console.log(" pHash similarity: " + phashsim);
				
				VSI = structuralsim + phashsim/2;  //average of structural and perceptual similarities 
				
				//rembrandsim = simRembrandt (loginimage, item);
													
				//Threat level 2 (lower): pages are similar and violates SOP. NOTE: SOP check needs to extend to sub-domain check
				if (VSI >= Tau2 & VSI < Tau1 & loginimage.host != item.host) {
					//notifoption.iconUrl = 'icons/icon48.png';
					notifoption.message = 'The website ' + item.host + " is probably SPOOFED by\n" + loginimage.host;
					chrome.notifications.create("", notifoption, function(id) {
						timer = setTimeout(function(){chrome.notifications.clear(id);}, 3000);
					});
				}	
				//Threat level 1 (higher): pages are the same and phishing attack must be reported
				else if (VSI >= Tau1 & loginimage.host != item.host) {
					notifoption.iconUrl = 'icons/phishing48.png';
					notifoption.requireInteraction = true;   //notification requires user interaction
					notifoption.message = 'The website ' + item.host + " has been SPOOFED by\n" + loginimage.host;
					chrome.notifications.create("", notifoption, function(id) {});
				}	
									
		}						
		imgitem.src = item.datab64;								
	}
	//if login page already exists in the database
	else found = true; 
	});
	
	return found;
}

 //Caputre, compare and save login page
 Extension.prototype.caputreLoginPage = function (tab, databases, automatic) {	
	
	//caputre screenshot of login page
	chrome.tabs.captureVisibleTab(windowid=tab.windowId,{"format":"jpeg"}, function(imgsource) {
				
		var url = tab.url;
		var pagehost = URI(url).hostname(); // getUrlBaseDomain(URI(url));	
		
			//create image object for login page identified
		    var loginpage = new Image();   				
			loginpage.onload = function () {
			    var canvas = document.createElement("canvas");
				canvas.width= 340; //this.width;
				canvas.height= 340; //this.height;						
				var ctx = canvas.getContext('2d');
				var imgdata = ctx.getImageData(0, 0, canvas.width, canvas.height); //ImageData object
				ctx.drawImage(loginpage, 0, 0, canvas.width, canvas.height);						
				var imgdatab64 = canvas.toDataURL("image/jpeg");  //base64 data
									
				//prepare image data structure. First FIVE fields are for structural similarity 
				var loginimage = {
					data: imgdata.data, //convertDataURIToBinary(imgdata),
					channels: 4,
					width: 340, //img.width,
					height: 340, //img.height	
					canvas: null,
					datab64: loginpage.src, //imgsource, //imgdatab64,		//for rembrandt browser				
					url: url, //URL of the image captured //loginpage.src,				//for rembrandt browser
					host: pagehost
				};						
					
				//databases.dba.put(loginimage, onsuccessput, onerrror);
				
				var onsuccessgetallb = function(data) {
					var found;
					console.log('Total images in the store B: '+data.length);
					found = phishCheck(data, loginpage, loginimage);
					//Page not in the store B either. Add to store C. 
					if (!found)
						//Page not in store A and B, add the captured image to store C. 
						databases.dbc.put(loginimage, onsuccessput, onerrror);  
					//replace old copy in store B with fresh copy
					else databases.dbb.put(loginimage, onsuccessput, onerrror); 
				}	
				
				var onsuccessgetalla = function(data) {					
					var found;
					console.log('Total images in the store A: '+data.length);
					found = phishCheck(data, loginpage, loginimage);
					//Page not in the store A. Look into store B
					if (!found) 	
					    databases.dbb.getAll(onsuccessgetallb, onerror); //read all pages from store B	
					else databases.dba.put(loginimage, onsuccessput, onerrror); //replace old copy in store A with fresh copy of the page
				}
				
				databases.dba.getAll(onsuccessgetalla, onerror); //read all pages from store A						
			}
			loginpage.src =  imgsource;    //'phashimges-temp/murraymeme.jpg';  //putting this above may create problems due to synchronous functions				
	});	
}

